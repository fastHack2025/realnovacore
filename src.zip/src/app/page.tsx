"use client";

import HeroDL from "@/components/HeroDL";
import CTASection from "@/components/CTASection";
import PricingGrid from "@/components/PricingGrid";
import TestimonialsDL from "@/components/TestimonialsDL";
import FAQ from "@/components/FAQ";
import ChatbotDavy from "@/components/ChatbotDavy";
import WhatsAppFloat from "@/components/WhatsAppFloat";
import RDVFloat from "@/components/RDVFloat";
import FooterDL from "@/components/FooterDL";

export default function Home() {
  return (
    <main className="bg-white text-gray-900 min-h-screen flex flex-col items-center overflow-x-hidden">
      {/* Section Hero avec vidéo immersive */}
      <HeroDL />

      {/* Section Appel à l'action */}
      <CTASection />

      {/* Section Tarifs/Offres */}
      <PricingGrid />

      {/* Témoignages clients */}
      <TestimonialsDL />

      {/* FAQ dynamique */}
      <FAQ />

      {/* Flottants : RDV rapide & WhatsApp support */}
      <RDVFloat />
      <WhatsAppFloat />

      {/* Chatbot IA intelligent */}
      <ChatbotDavy />

      {/* Footer complet */}
      <FooterDL />
    </main>
  );
}
