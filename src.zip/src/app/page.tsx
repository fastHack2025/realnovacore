'use client';

import HeaderMegaMenu from '@/components/HeaderMegaMenu';
import Hero from '@/components/Hero';
import HeroNovaCore from '@/components/HeroNovaCore';
import HeroDL from '@/components/HeroDL';
import ModulesNovaCore from '@/components/HomeModules';
import FooterDL from '@/components/FooterDL';
import { motion } from 'framer-motion';

export default function HomePage() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1 }}
      className="flex flex-col bg-gradient-to-b from-black via-gray-900 to-black"
    >
      {/* Header Mega Menu */}
      <HeaderMegaMenu />

      {/* Hero Animation IA */}
      <Hero />

      {/* Hero Section NovaCore */}
      <HeroNovaCore />

      {/* Hero Section DL Solutions */}
      <HeroDL />

      {/* Modules CRM - ERP - IA */}
      <ModulesNovaCore />

      {/* Footer DL Solutions */}
      <FooterDL />
    </motion.div>
  );
}
