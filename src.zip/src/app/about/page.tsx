import React from "react";

export default function AboutPage() {
  return (
    <main className="bg-gradient-to-r from-indigo-50 via-white to-indigo-100 min-h-screen flex flex-col items-center justify-center px-6 py-16">
      <h1 className="text-5xl font-extrabold text-indigo-700 mb-6 animate-fadeInUp">À propos de DL Solutions</h1>
      <p className="text-lg text-gray-600 max-w-3xl text-center animate-slideIn">
        DL Solutions est spécialisée dans l'innovation IA pour transformer les entreprises du futur. 
        Avec NovaCore, nous repoussons les limites du CRM, des paiements, des RDV, et du marketing IA.
      </p>
    </main>
  );
}
