export default function Head() {
  return (
    <>
      <title>DL Solutions | NovaCore CRM ERP IA Digitalisation</title>
      <meta name="description" content="NovaCore propulse votre entreprise dans l'ère de la digitalisation grâce à notre CRM intelligent, ERP flexible et IA puissante." />
      <meta name="keywords" content="CRM, ERP, IA, Intelligence Artificielle, NovaCore, DL Solutions, SaaS, Digitalisation" />
      <meta property="og:title" content="DL Solutions - NovaCore Platform CRM ERP IA" />
      <meta property="og:description" content="Solutions professionnelles CRM, ERP et IA adaptées aux entreprises modernes. Boostez votre croissance avec NovaCore." />
      <meta property="og:type" content="website" />
      <meta property="og:url" content="https://www.dlsolutions.com" />
      <meta property="og:image" content="https://res.cloudinary.com/dko5sommz/image/upload/v1745726808/Design_sans_titre_x3pcna.png" />
      <meta name="twitter:card" content="summary_large_image" />
    </>
  );
}
