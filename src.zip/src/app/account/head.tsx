export default function Head() {
  return (
    <>
      <title>Mon Compte - NovaCore</title>
      <meta name="description" content="Gérez votre profil, votre abonnement et vos informations de facturation NovaCore." />
    </>
  );
}
