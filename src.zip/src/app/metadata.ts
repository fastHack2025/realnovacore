export const metadata = {
    title: "NovaCore",
    description: "Plateforme IA multiactivité by DL Solutions",
  };
  