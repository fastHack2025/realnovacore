// src/app/layout.tsx
import { ClerkProvider } from '@clerk/nextjs';
import { ReactNode } from 'react';
import './globals.css';

export const metadata = {
  title: 'DL Solutions - NovaCore',
  description: 'Solutions digitales innovantes en Europe | Développement Web, IA, SEO',
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon-96x96.png',
    apple: '/apple-touch-icon.png',
    other: [
      {
        rel: 'manifest',
        url: '/site.webmanifest',
      },
      {
        rel: 'icon',
        url: '/favicon.svg',
      }
    ]
  }
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <ClerkProvider publishableKey={process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY}>
      <html lang="fr">
        <body>{children}</body>
      </html>
    </ClerkProvider>
  );
}
