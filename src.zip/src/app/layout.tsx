'use client';

import { ClerkProvider } from '@clerk/nextjs';
import Navbar from '@/components/Navbar';
import './globals.css';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="fr">
        <body className="bg-black text-white">
          <Navbar /> {/* ✅ Navbar universelle */}
          <main className="pt-24">{children}</main> {/* ✅ Décalage sous la Navbar */}
        </body>
      </html>
    </ClerkProvider>
  );
}
