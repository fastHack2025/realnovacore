import React from "react";

export default function ContactPage() {
  return (
    <main className="bg-gradient-to-r from-sky-50 via-white to-sky-100 min-h-screen flex flex-col items-center justify-center px-6 py-16">
      <h1 className="text-5xl font-extrabold text-sky-700 mb-6 animate-fadeInUp">Contactez DL Solutions</h1>
      <p className="text-lg text-gray-600 max-w-2xl text-center mb-8 animate-slideIn">
        Besoin d’assistance ? Parlons-en ! 🚀
      </p>
      <form className="w-full max-w-lg space-y-6">
        <input type="text" placeholder="Votre Nom" className="input-field" />
        <input type="email" placeholder="Votre Email" className="input-field" />
        <textarea placeholder="Votre Message" className="input-field h-40" />
        <button className="px-8 py-3 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-lg transition-all animate-bounce">
          Envoyer le message
        </button>
      </form>
    </main>
  );
}
