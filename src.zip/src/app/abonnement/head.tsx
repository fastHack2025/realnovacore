export default function Head() {
    return (
      <>
        <title>Abonnement NovaCore</title>
        <meta name="description" content="Abonnez-vous pour accéder aux fonctionnalités Premium NovaCore." />
      </>
    );
  }
  