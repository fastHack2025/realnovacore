// src/app/[locale]/page.tsx
export default function LocalizedHome() {
    return (
      <main className="p-10">
        <h1 className="text-3xl font-bold">Bienvenue sur la page traduite 🌍</h1>
      </main>
    )
  }
  