export const notifications = [
    {
      id: 1,
      title: "🚀 Nouvelle Opportunité CRM",
      date: "2025-04-27",
    },
    {
      id: 2,
      title: "🛠️ Maintenance serveur prévue",
      date: "2025-04-28",
    },
    {
      id: 3,
      title: "🎯 Objectif mensuel atteint",
      date: "2025-04-26",
    },
  ];
  