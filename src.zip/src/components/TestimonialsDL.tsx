"use client";

export default function TestimonialsDL() {
  return (
    <section className="bg-indigo-50 py-20 px-6">
      <div className="max-w-6xl mx-auto text-center">
        <h2 className="text-3xl md:text-5xl font-bold mb-10 text-gray-900">Ils nous font confiance</h2>
        <div className="grid md:grid-cols-2 gap-10">
          <blockquote className="p-6 bg-white rounded-xl shadow-md">
            <p className="text-gray-700 italic">"NovaCore a révolutionné notre CRM hôtelier en quelques semaines."</p>
            <footer className="mt-4 font-semibold">— Hôtel Le Prestige</footer>
          </blockquote>
          <blockquote className="p-6 bg-white rounded-xl shadow-md">
            <p className="text-gray-700 italic">"Le studio IA nous permet de générer du contenu marketing 10x plus vite."</p>
            <footer className="mt-4 font-semibold">— Agence Nova</footer>
          </blockquote>
        </div>
      </div>
    </section>
  );
}
