"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import AuthButtons from "@/components/AuthButtons";

export default function Header() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled ? "bg-white shadow-md" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto flex justify-between items-center p-4">
        {/* Logo DL Solutions */}
        <Link href="/">
          <div className="flex items-center gap-3">
            <Image
              src="/icons/logo-dlsolutions.png"
              alt="DL Solutions Logo"
              width={48}
              height={48}
              className="rounded-full object-cover"
            />
            <span className="font-bold text-xl text-primary">DL Solutions</span>
          </div>
        </Link>

        {/* Menu principal */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-semibold">
          <Link href="/" className="hover:text-primary transition">Accueil</Link>
          <Link href="/portfolio" className="hover:text-primary transition">Portfolio</Link>
          <Link href="/crm" className="hover:text-primary transition">CRM</Link>
          <Link href="/paiements" className="hover:text-primary transition">Paiements</Link>
          <Link href="/rdv" className="hover:text-primary transition">RDV</Link>
          <Link href="/contact" className="hover:text-primary transition">Contact</Link>
        </nav>

        {/* Boutons Connexion / Inscription */}
        <div className="flex items-center gap-4">
          <AuthButtons />
        </div>
      </div>
    </header>
  );
}
