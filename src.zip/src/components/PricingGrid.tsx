"use client";

export default function PricingGrid() {
  return (
    <section id="pricing" className="bg-gray-100 py-20 px-6">
      <div className="max-w-6xl mx-auto text-center">
        <h2 className="text-3xl md:text-5xl font-bold mb-10 text-gray-900">Nos Offres</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Plan basique */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h3 className="text-2xl font-semibold mb-4 text-indigo-700">Starter</h3>
            <p className="text-4xl font-bold mb-6">€29<span className="text-sm">/mois</span></p>
            <ul className="space-y-4 text-gray-600 mb-6">
              <li>Accès CRM</li>
              <li>Studio IA basique</li>
              <li>Support email</li>
            </ul>
            <a href="/inscription" className="block bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-lg font-semibold transition">
              Commencer
            </a>
          </div>

          {/* Plan business */}
          <div className="bg-white rounded-2xl shadow-lg p-8 border-2 border-indigo-600">
            <h3 className="text-2xl font-semibold mb-4 text-indigo-700">Business</h3>
            <p className="text-4xl font-bold mb-6">€79<span className="text-sm">/mois</span></p>
            <ul className="space-y-4 text-gray-600 mb-6">
              <li>Accès complet CRM + IA</li>
              <li>Automatisation sociale</li>
              <li>Support prioritaire</li>
            </ul>
            <a href="/inscription" className="block bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-lg font-semibold transition">
              Choisir
            </a>
          </div>

          {/* Plan entreprise */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h3 className="text-2xl font-semibold mb-4 text-indigo-700">Enterprise</h3>
            <p className="text-4xl font-bold mb-6">€149<span className="text-sm">/mois</span></p>
            <ul className="space-y-4 text-gray-600 mb-6">
              <li>Solutions personnalisées</li>
              <li>Support VIP 24/7</li>
              <li>Intégrations avancées</li>
            </ul>
            <a href="/contact" className="block bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-lg font-semibold transition">
              Nous contacter
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
