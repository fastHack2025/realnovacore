'use client';

import Link from 'next/link';
import { SignedIn, SignedOut, UserButton } from '@clerk/nextjs';
import { useEffect, useState } from 'react';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { href: '/', label: 'Accueil' },
    { href: '/services', label: 'Services' },
    { href: '/projects', label: 'Réalisations' },
    { href: '/contact', label: 'Contact' },
    { href: '/equipe', label: 'Notre Équipe' },
  ];

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <>
      <header className={`fixed top-0 left-0 w-full z-50 transition-all ${isScrolled ? 'bg-white/10 backdrop-blur-xl shadow-lg' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          {/* Logo */}
          <Link href="/">
            <Image
              src="/logo.png"
              alt="Logo DL Solutions"
              width={60}
              height={60}
              priority
              className="rounded-full border-2 border-white shadow-md object-contain"
            />
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8 items-center">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`font-semibold transition ${
                  pathname === link.href ? 'text-indigo-400' : 'text-white hover:text-indigo-300'
                }`}
              >
                {link.label}
              </Link>
            ))}

            {/* Signed In */}
            <SignedIn>
              <UserButton afterSignOutUrl="/" />
            </SignedIn>

            {/* Signed Out */}
            <SignedOut>
              <Link
                href="/sign-in"
                className="px-4 py-2 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 transition font-bold"
              >
                Connexion
              </Link>
            </SignedOut>
          </nav>

          {/* Hamburger Icon */}
          <button
            className="md:hidden text-white focus:outline-none"
            onClick={toggleMenu}
            aria-label="Menu"
          >
            {isMenuOpen ? '✖️' : '☰'}
          </button>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.nav
              initial={{ height: 0 }}
              animate={{ height: "auto" }}
              exit={{ height: 0 }}
              transition={{ duration: 0.3 }}
              className="md:hidden bg-black/90 backdrop-blur-xl w-full flex flex-col items-center space-y-6 py-8"
            >
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setIsMenuOpen(false)}
                  className={`text-xl font-bold ${
                    pathname === link.href ? 'text-indigo-400' : 'text-white hover:text-indigo-300'
                  }`}
                >
                  {link.label}
                </Link>
              ))}

              {/* Connexion/Déconnexion Mobile */}
              <SignedIn>
                <UserButton afterSignOutUrl="/" />
              </SignedIn>

              <SignedOut>
                <Link
                  href="/sign-in"
                  onClick={() => setIsMenuOpen(false)}
                  className="px-6 py-3 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 transition font-bold"
                >
                  Connexion
                </Link>
              </SignedOut>
            </motion.nav>
          )}
        </AnimatePresence>
      </header>
    </>
  );
}
