"use client";

import { useState, useEffect } from "react";

export default function CookieConsentBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("cookie-consent");
    if (!consent) setVisible(true);
  }, []);

  const acceptCookies = () => {
    localStorage.setItem("cookie-consent", "true");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 p-4 bg-gray-800 text-white rounded-lg flex justify-between items-center shadow-lg z-[9999]">
      <span>Nous utilisons des cookies pour améliorer votre expérience.</span>
      <button
        onClick={acceptCookies}
        className="ml-4 bg-primary text-white px-4 py-2 rounded hover:bg-primary-dark transition"
      >
        Accepter
      </button>
    </div>
  );
}
