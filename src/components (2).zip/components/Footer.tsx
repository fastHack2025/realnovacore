"use client";

import Link from "next/link";
import Image from "next/image";

export default function Footer() {
  return (
    <footer className="bg-gray-100 py-10 mt-20 text-gray-700">
      <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-3 gap-10">
        
        {/* Logo + description */}
        <div className="flex flex-col items-start gap-4">
          <Image
            src="/icons/logo-dlsolutions.png"
            alt="DL Solutions Logo"
            width={64}
            height={64}
            className="rounded-full object-cover"
          />
          <p className="text-sm">DL Solutions - Expertise digitale et intelligence artificielle pour votre business 🚀</p>
        </div>

        {/* Menu rapide */}
        <div className="flex flex-col gap-3">
          <span className="text-primary font-bold text-lg mb-2">Navigation</span>
          <Link href="/" className="hover:underline">Accueil</Link>
          <Link href="/portfolio" className="hover:underline">Portfolio</Link>
          <Link href="/crm" className="hover:underline">CRM</Link>
          <Link href="/paiements" className="hover:underline">Paiements</Link>
          <Link href="/rdv" className="hover:underline">Prendre RDV</Link>
        </div>

        {/* Réseaux sociaux */}
        <div className="flex flex-col gap-3">
          <span className="text-primary font-bold text-lg mb-2">Suivez-nous</span>
          <div className="flex gap-4">
            <Link href="#"><Image src="/icons/facebook.svg" alt="Facebook" width={32} height={32} /></Link>
            <Link href="#"><Image src="/icons/instagram.svg" alt="Instagram" width={32} height={32} /></Link>
            <Link href="#"><Image src="/icons/linkedin.svg" alt="LinkedIn" width={32} height={32} /></Link>
            <Link href="#"><Image src="/icons/twitter.svg" alt="Twitter" width={32} height={32} /></Link>
            <Link href="#"><Image src="/icons/whatsapp.svg" alt="Whatsapp" width={32} height={32} /></Link>
          </div>
        </div>

      </div>

      <div className="text-center text-xs text-gray-500 mt-10">
        © 2025 DL Solutions. Tous droits réservés.
      </div>
    </footer>
  );
}
