"use client";

export default function HeroDL() {
  return (
    <section className="relative h-screen w-full overflow-hidden">
      {/* Vidéo Hero */}
      <video
        autoPlay
        muted
        loop
        playsInline
        className="absolute inset-0 w-full h-full object-cover z-[-1]"
        src="https://res.cloudinary.com/dko5sommz/video/upload/v1745331051/mon_site_web_aqda4c.mkv"
      />

      {/* Logo animé */}
      <img
        src="https://res.cloudinary.com/dko5sommz/image/upload/v1744370550/logo-novacore_iqi2pd.png"
        alt="NovaCore Logo"
        className="absolute top-12 left-12 w-20 h-20 animate-bounce rounded-full bg-white p-2 shadow-lg z-10"
      />

      {/* Texte central */}
      <div className="relative z-10 h-full flex flex-col items-center justify-center text-white text-center px-6">
        <h1 className="text-5xl md:text-6xl font-extrabold drop-shadow-2xl">
          Bienvenue sur <span className="text-indigo-400">NovaCore</span>
        </h1>
        <p className="mt-6 text-xl md:text-2xl max-w-2xl drop-shadow-lg">
          La plateforme IA tout-en-un pour l’élite du digital.
        </p>
        <a
          href="/offres"
          className="mt-8 px-6 py-3 bg-indigo-600 text-white rounded-xl text-lg font-semibold hover:bg-indigo-700 shadow-xl transition-all"
        >
          Découvrir les modules
        </a>
      </div>
    </section>
  );
}
