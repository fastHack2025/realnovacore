'use client';

import { ClerkProvider } from '@clerk/nextjs';
import Navbar from '@/components/Navbar';
import './globals.css';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="fr">
        <body className="min-h-screen flex flex-col bg-black text-white scroll-smooth overflow-x-hidden">
          <Navbar />
          <main className="flex-1 pt-24">
            {children}
          </main>
        </body>
      </html>
    </ClerkProvider>
  );
}
