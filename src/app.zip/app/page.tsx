'use client';

import HeaderMegaMenu from '@/components/HeaderMegaMenu';
import Hero from '@/components/Hero';
import HeroNovaCore from '@/components/HeroNovaCore';
import HeroDL from '@/components/HeroDL';
import HomeModules from '@/components/HomeModules';
import ServicesSection from '@/components/ServicesSection';
import PricingSection from '@/components/PricingSection';
import TestimonialsSection from '@/components/TestimonialsSection';
import FAQSection from '@/components/FAQSection';
import FooterDL from '@/components/FooterDL';
import { motion } from 'framer-motion';

export default function HomePage() {
  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1 }}
      className="flex flex-col bg-gradient-to-b from-black via-gray-900 to-black min-h-screen"
    >
      {/* Mega Navbar */}
      <HeaderMegaMenu />

      {/* Animation IA Canvas */}
      <Hero />

      {/* Présentation NovaCore */}
      <HeroNovaCore />

      {/* Présentation DL Solutions */}
      <HeroDL />

      {/* Modules CRM ERP IA */}
      <HomeModules />

      {/* Nos Services */}
      <ServicesSection />

      {/* Tarification */}
      <PricingSection />

      {/* Témoignages Clients */}
      <TestimonialsSection />

      {/* FAQ Section */}
      <FAQSection />

      {/* Footer */}
      <FooterDL />
    </motion.main>
  );
}
