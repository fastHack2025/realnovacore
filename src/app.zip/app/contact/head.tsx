export default function Head() {
    return (
      <>
        <title>Contact | DL Solutions</title>
        <meta name="description" content="Prenez contact avec DL Solutions pour propulser votre entreprise avec NovaCore CRM ERP IA." />
      </>
    );
  }
  